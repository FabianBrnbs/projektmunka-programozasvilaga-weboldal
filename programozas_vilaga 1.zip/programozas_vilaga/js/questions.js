let questions = [
    {
    numb: 1,
    question: "Mi tartozik a jó példák közé?",
    answer: "A stílusokat external fájlból olvassa be",
    options: [
      "A stílusokat external fájlból olvassa be",
      "Sok inline stílust alkalmaz",
      "A változók nevét túlbonyolítja",
      "A stílusokat HTML címkékbe ágyazza"
    ]
  },
    {
    numb: 2,
    question: "Az alábbiak közül melyik dolgozik leginkább gyűjteménytípusokkal?",
    answer: "foreach loop",
    options: [
      "for loop",
      "foreach loop",
      "do while loop",
      "while loop"
    ]
  },
    {
    numb: 3,
    question: "Hogyan helyes a következő állítás: ... szam = 5;",
    answer: "int",
    options: [
      "int",
      "char",
      "string",
      "long"
    ]
  },
    {
    numb: 4,
    question: "Az alábbiak közül melyiket érdemes használni, amikor tudjuk, hogy hány iterációra van szükség?",
    answer: "for loop",
    options: [
      "foreach loop",
      "do while loop",
      "while loop",
      "for loop"
    ]
  },
    {
    numb: 5,
    question: "Melyik a helyes állítás?",
    answer: "double atlag = 4.5",
    options: [
      "string nev = Fábián Barnabás",
      "char jegy = 5",
      "double atlag = 4.5",
      "int eletkor = 18.5"
    ]
  },
];